package atividade1;

public class ProgramaPrincipal {

	public static void main(String[] args) {
		
		ClasseFilha f1 = new ClasseFilha();
		
		ClassePai f2 = new ClasseFilha();

	}

}
