package atividade1;

public class ClassePai {
	
	public ClassePai() {
		
	}
	
	public void metodoA() {
		
	}
	
	public void metodoB() {
		
	}
	

}
