package atividade1;

public class ClasseFilha extends ClassePai {
	
	public ClasseFilha() {
		super();
	}
	
	public void metodoC() {
		
	}

}
