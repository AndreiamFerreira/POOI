package atividade2;

public class ProgramaPrincipal {

	public static void main(String[] args) {
		
		Cachorro c1 = new Cachorro("Tobi", "Vira-lata");
		
		Gato g1 = new Gato("Garfield", "Persa");
		
		Cavalo c2 = new Cavalo("Cavalo", "Crioulo", true);
		
				
	}

}
