package atividade2;

public class Gato extends Animal {

	public Gato(String nome, String raca) {
		super(nome, raca);
		
	}
	
	public void cacarRatos() {
		System.out.println("Gato ca�ando rato");
	}

	public void respirar() {
		System.out.println("Gato est� respirando");
		
	}
	
	

}
